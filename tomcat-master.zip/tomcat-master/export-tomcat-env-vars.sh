#!/bin/bash

echo -e "###### ./tomcat-env-vars.sh">>~/.bashrc
cat ./tomcat-env-vars.sh >>~/.bashrc
