#!/bin/bash

source ./tomcat-env-vars.sh
source ./download-tomcat.sh

$TOMCAT_START
